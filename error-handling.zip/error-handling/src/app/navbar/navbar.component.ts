import {Component} from '@angular/core'
@Component({
    selector:'app-nav-bar',
    templateUrl:'./navbar.component.html'
})

export class NavBarComponent {

}